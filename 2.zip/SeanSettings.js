require("./SeanBase/module.js")

//========== Global Setting ==========//
global.owner = "62856004625329"
global.namaowner = "Rex Official"
global.namabot = "Rex Bot" 
global.author = "Rex"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})