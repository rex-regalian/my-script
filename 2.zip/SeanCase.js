module.exports = async (RexDev, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await RexDev.decodeJid(RexDev.user.id)
const premium = JSON.parse(fs.readFileSync('./SeanBase/database/premium.json'));
const owner = JSON.parse(fs.readFileSync('./SeanBase/database/owner.json'));
const isPremium = [m.sender+'@s.whatsapp.net', premium+'@s.whatsapp.net', owner+'@s.whatsapp.net', botNumber+'@s.whatsapp.net',global.owner+'@s.whatsapp.net']
const isOwner = [m.sender+'@s.whatsapp.net', owner+'@s.whatsapp.net', botNumber+'@s.whatsapp.net', global.owner+'@s.whatsapp.net']
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await RexDev.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./SeanBase/function.js')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./SeanBase/converter.js")

if (isCmd) {
console.log(chalk.white.bgRed.bold(`『 SEAN SCRIPT 』\n`), chalk.white.bgBlue.bold(`Dari ${senderNumber}`), chalk.white.bgBlack.bold(`${cmd}`))
}

const fkontak = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": 'The Sean Script first Version',
                    "jpegThumbnail": ''
                          }
                        }
                      }

const reply = (teks) => {
return RexDev.sendMessage(m.chat, {
contextInfo: {
mentionedJid: ['0@s.whatsapp.net'],
externalAdReply: {
showAdAttribution: true,
title: "SEAN SCRIPT",
body: "Version 1.0",
thumbnailUrl: 'https://i.supa.codes/RIpNg1',
sourceUrl: 'https://youtube.com/@rexofficialbot',
mediaType: 1,
renderLargerThumbnail: false
}
},
text: teks
}, {
quoted: fkontak
})
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

switch (command) {

case "start1": {
const textnya = `    *Mode Bot :* ${RexDev.public ? "Public" : "Self"}
    *Ownerbot :* ${global.owner}
 
    *Mainmenu*
    ⏣  • .tourl
    ⏣  • .tovn
    ⏣  • .tomp3
    ⏣  • .toptv
    ⏣  • .tts
    ⏣  • .toimg
    ⏣  • .remini
    ⏣  • .sticke

    *Pushkontakmenu*
    ⏣  • .pushkontak
    ⏣  • .pushkontakid
    ⏣  • .listgc
    ⏣  • .idgc
    ⏣  • .jpm
    ⏣  • .jpmfoto
    ⏣  • .jpmht
`
RexDev.sendMessage(m.chat, {text: textnya, contextInfo: {mentionedJid: [m.sender], externalAdReply: {showAdAttribution: true, thumbnailUrl: "https://files.catbox.moe/eoc0kl.jpg", title: `© ${global.namabot}`, body: null, sourceUrl: "https://rex-entertainment.github.io/heppy", renderLargerThumbnail: true, mediaType: 1}}}, {quoted: fkontak})
}
break

case "start": {
const menu = `
*─╍─╍─╍─*
ᴛᴇʀɪᴍᴀᴋᴀsɪʜ ᴛᴇʟᴀʜ 
ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ sᴄʀɪᴘᴛ ɪɴɪ. 
ɢᴜɴᴀᴋᴀɴ ᴅᴇɴɢᴀɴ ʙɪᴊᴀᴋ 
ᴅᴀɴ ʙᴇʀᴛᴀɴɢɢᴜɴɢᴊᴀᴡᴀʙ. 
*─╍─╍─╍─*

╔╍『 MENU UTAMA 』╍═≫
┇↺ ᴀʟʟᴍᴇɴᴜ
║↺ ᴏᴡɴᴇʀᴍᴇɴᴜ
┇↺ ᴏᴛʜᴇʀᴍᴇɴᴜ
║↺ ʙᴜɢᴍᴇɴᴜ
┇↺ ᴘᴜsʜᴍᴇɴᴜ
╚╍═╍═╍═╍≫

© Rex Dev
`
await RexDev.sendMessage(m.chat, {
  video: { url: "https://files.catbox.moe/6su4ii.mp4" },
  gifPlayback: true,
  caption: menu,
  contextInfo: {
    isForwarded: true,
    mentionedJid: [m.sender],
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363319719284496@newsletter",
      newsletterName: "Whatsapp Channel Rex Official"
    }, 
    externalAdReply: {
      showAdAttribution: true,
      title: "SEAN SCRIPT",
      body: "Version 1.0",
      thumbnailUrl: 'https://i.supa.codes/RIpNg1',
      sourceUrl: 'https://youtube.com/@rexofficialbot',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  }
}, { quoted: fkontak } );

  await RexDev.sendMessage(
    m.chat,
    { audio: { url: "https://files.catbox.moe/5esb7n.mp3" }, mimetype: "audio/mp4", ptt: true },
    { quoted: fkontak }
  );
}
break

case "ownermenu": {
const menu = `
╔╍『 MENU OWNER 』╍═≫
┇↺ ᴀᴅᴅᴘʀᴇᴍ
║↺ ᴅᴇʟᴘʀᴇᴍ
┇↺ ᴀᴅᴅᴏᴡɴᴇʀ
║↺ ᴅᴇʟᴏᴡɴᴇʀ
┇↺ ʀᴇsᴛᴀʀᴛ
╚╍═╍═╍═╍≫

© Rex Dev
`
await RexDev.sendMessage(m.chat, {
  video: { url: "https://files.catbox.moe/6su4ii.mp4" },
  gifPlayback: true,
  caption: menu,
  contextInfo: {
    isForwarded: true,
    mentionedJid: [m.sender],
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363319719284496@newsletter",
      newsletterName: "Whatsapp Channel Rex Official"
    }, 
    externalAdReply: {
      showAdAttribution: true,
      title: "SEAN SCRIPT",
      body: "Version 1.0",
      thumbnailUrl: 'https://i.supa.codes/RIpNg1',
      sourceUrl: 'https://youtube.com/@rexofficialbot',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  }
}, { quoted: fkontak } );

  await RexDev.sendMessage(
    m.chat,
    { audio: { url: "https://files.catbox.moe/5esb7n.mp3" }, mimetype: "audio/mp4", ptt: true },
    { quoted: fkontak }
  );
}
break

case "tts": {
if (!text) return reply(`Contoh\n${cmd} Teks`)
if (text.length >= 300) return reply("Jumlah huruf harus di bawah 300!")
let id = 'id_001'
try {
const { data } = await axios.post("https://tiktok-tts.weilnet.workers.dev/api/generation", {
    "text": text,
    "voice": id
})
RexDev.sendMessage(m.chat, { 
audio: Buffer.from(data.data, "base64"), 
mimetype: "audio/mp4" }, {quoted: fkontak})
} catch (e) {
return reply(e.toString())
}
}
break
case "toptv": {
if (/video/.test(qmsg.mimetype)) {
if ((qmsg).seconds > 30) return reply("Durasi Vidio Maksimal 30 Detik!")
let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: qmsg }), { userJid: m.chat, quoted: fkontak })
RexDev.sendMessage(m.chat, ptv.message, { messageId: ptv.key.id })
} else { 
return reply(`Contoh\n${cmd} [ Dengan Mengirim / Reply Vidio ]`)
}
}
break
case "toimage": case "toimg": {
if (!/webp/.test(mime) && !/audio/.test(mime)) return reply(`Contoh\n${cmd} Dengan Reply Stiker`)
let media = await RexDev.downloadAndSaveMediaMessage(qmsg)
let ran = `${makeid}.png`
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return err
let buffer = fs.readFileSync(ran)
RexDev.sendMessage(m.chat, {image: buffer}, )
fs.unlinkSync(ran)
})
}
break
case "tovn": case "toptt": {
if (!/video|audio/.test(mime) && !/audio/.test(mime)) return reply(`Contoh\n${cmd} [ Dengan Mengirim / Reply Mp3 / Mp4 ]`)
await RexDev.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toPTT(res, 'mp4')
RexDev.sendMessage(m.chat, {audio: anu, mimetype: 'audio/mpeg', ptt: true}, {quoted : fkontak}) 
})
}
break
case "toaudio": case "tomp3": {
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Contoh\n${cmd} [ Dengan Reply Vidio ]`)
if ((qmsg).seconds > 30) return reply("Durasi Vidio Maksimal 30 Detik")
await RexDev.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toAudio(res, 'mp4')
RexDev.sendMessage(m.chat, {audio: anu, mimetype: 'audio/mpeg'}, {quoted : fkontak}) 
})
}
break
case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return reply(`Contoh\n${cmd} [ Dengan Mengirim / Reply Foto / Video ]`)
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return reply("Durasi Vidio Maksimal 15 Detik!")
}
var media = await RexDev.downloadAndSaveMediaMessage(qmsg)
await RexDev.sendStimg(m.chat, media, m, {packname: "Sean Script"})
await fs.unlinkSync(media)
}
break
case "public": {
if (!isOwner) return reply("Khsusus Owner")
RexDev.public = true
reply("Berhasil Mengganti Mode Bot Menjadi Public")
}
break
case "self": {
if (!isOwner) return reply("Khusus Owner")
RexDev.public = false
reply("Berhasil Mengganti Mode Bot Menjadi Self")
}
break
case 'hd': 
  case 'remini': {
      if (!quoted) return replycann(`Contoh\n${cmd} Dengan Kirim / Reply Foto`)
      if (!/image/.test(mime)) return replycann(`Contoh\n${cmd} Dengan Kirim / Reply Foto`)
      try {
          const { remini } = require('./SeanBase/remini')
          let media = await quoted.download()
          for (let i = 0; i < 3; i++) {
              media = await remini(media, "enhance")
          }
          RexDev.sendMessage(m.chat, { image: media, caption: `Berhasil`}, { quoted: fkontak})
      } catch (error) {
          console.error(error)
          reply('error jawir')
      }
  }
  break
case 'tourl': {
const FormData = require("form-data");
const { fromBuffer } = require("file-type");
const fakeUserAgent = require("fake-useragent");
const { filesize } = require('filesize');
	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || ''
	const createFormData = (content, fieldName, ext) => {
 const { mime } = fromBuffer(content) || {};
 const formData = new FormData();
 formData.append(fieldName, content, `${new Date()}.${ext}`);
 return formData;
};

const catbox = async (content) => {
 try {
 /*
 @ CatBox Uploader
 $ Create by Syaii
 */
 const { ext, mime } = (await fromBuffer(content)) || {};
 const formData = createFormData(content, "fileToUpload", ext);
 formData.append("reqtype", "fileupload");
 const response = await fetch("https://catbox.moe/user/api.php", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": fakeUserAgent(),
 },
 });
 return await response.text();
 } catch (error) {
 throw false;
 }
 }
	if (!mime) return reply(`Contoh\n${cmd} Dengan Kirim / Reply Media`)
	let media = await q.download()
	let link = await catbox(media)
	let size = await fetch(link)
	size = await size.text()
	size = await filesize(size.length)
	let caption = `Berhasil

Ukuran : ${size} Byte
Link : ${link}
`
await RexDev.sendMessage(m.chat,{image: {url: link}, caption: caption }, { quoted: fkontak })
}
break
case "addowner":
if (!isOwner) return reply("Khusus Owner")
if (!args[0]) return reply(`Contoh\n${cmd} 628××× / Tag`)
alamak = q.split("|")[0].replace(/[^0-9]/g, '')
let ngwe = await RexDev.onWhatsApp(alamak + `@s.whatsapp.net`)
if (ngwe.length == 0) return reply(`Tolong Masukan Nomor Yang Failed`)
owner.push(alamak)
fs.writeFileSync('./SeanBase/database/owner.json', JSON.stringify(owner))
reply(`Sukses Menambahkan ${alamak}@s.whatsapp.net Ke Database Owner`)
break

case "delowner":
if (!isOwner) return reply("Khusus Owner")
if (!args[0]) return reply(`Contoh\n${cmd} 628××× / Tag`)
alamakk = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(alamakk)
owner.splice(unp, 1)
fs.writeFileSync('./SeanBase/database/owner.json', JSON.stringify(owner))
reply(`Sukses Menghapus ${alamakk}@s.whatsapp.net Dari Database Owner`)
break

case 'addprem':
if (!isOwner) return reply("Khusus Owner")
if (!args[0]) return reply(`Contoh\n${cmd} 628××× / Tag`)
alamakkk = text.split("|")[0].replace(/[^0-9]/g, '')
let ngwee = await RexDev.onWhatsApp(alamakkk + `@s.whatsapp.net`)
if (ngwee.length == 0) return reply(`Tolong Masukan Nomor Yang Failed`)
premium.push(alamakkk)
fs.writeFileSync('./SeanBase/database/premium.json', JSON.stringify(premium))
reply(`Sukses Menambahkan ${alamakkk}@s.whatsapp.net Ke Database Premium`)
break

case 'delprem':
if (!isOwner) return reply("Khusus Owner")
if (!args[0]) return reply(`Contoh\n${cmd} 628××× / Tag`)
alamakkkk = text.split("|")[0].replace(/[^0-9]/g, '')
unp = premium.indexOf(alamakkkk)
premium.splice(unp, 1)
fs.writeFileSync('./SeanBase/database/premium.json', JSON.stringify(premium))
reply(`Sukses Menghapus ${alamakkkk}@s.whatsapp.net Dari Database Premium`)
break
case "restart": case "rst": {
if (!isOwner) return reply("Khusus Owner")
await reply(`Restarting Server..!!\nTunggu Sekitar 5 - 10 Detik`)
setTimeout(() => {
process.send("reset")
}, 3000)
}
break
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return RexDev.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return RexDev.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
RexDev.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
RexDev.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return RexDev.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return RexDev.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
RexDev.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})