import chalk from 'chalk';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { issmsg } from './SeanBase/SeanLibrary/SeanFunction.js';

const __filename = fileURLToPath(import.meta.url);

fs.watchFile(__filename, () => {
fs.unwatchFile(__filename);
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ update pada ${__filename}`));
delete require.cache[__filename];
require(__filename);
});