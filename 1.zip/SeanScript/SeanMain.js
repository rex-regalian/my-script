import './SeanSettings.js';
import * as baileys from '@whiskeysockets/baileys';
import qrcode from 'qrcode-terminal';
import fs from 'fs';
import pino from 'pino';
import PhoneNumber from 'awesome-phonenumber';
import readline from 'readline';
import { issmsg } from './SeanBase/SeanLibrary/SeanFunction.js';
import chalk from 'chalk';
import chalkAnimation from 'chalk-animation';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const { proto, makeWASocket, useMultiFileAuthState, makeInMemoryStore, jidDecode } = baileys;
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const UseCode = true;
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, (answer) => {
rl.close();
resolve(answer);
});
});
};

async function RexStartBot() {
try {
const { state, saveCreds } = await useMultiFileAuthState('./SeanSession');
const RexDev = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !UseCode,
auth: state,
browser: ["Ubuntu", "Chrome", "20.0.04"]
});
if (UseCode && !RexDev.authState.creds.registered) {
const phoneNumber = await question(chalk.white.bgRed.bold(
`┏═━═━═━═━═━ ≫
╠ ⪼ masukan nomer bot kamu
┗ ⪼ `));
const CodeConnect = await RexDev.requestPairingCode(phoneNumber.trim());
console.log(chalk.white.bgRed.bold(
`┏═━═━═━═━═━ ≫
╠ ⪼ kode pairing kamu
┗ ⪼ ${CodeConnect}`));
}
store.bind(RexDev.ev);
RexDev.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return (decode.user && decode.server) ? `${decode.user}@${decode.server}` : jid;
} else return jid;
};
RexDev.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update;
if (connection === 'close') {
const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== 401;
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ koneksi gagal`, shouldReconnect));
if (shouldReconnect) RexStartBot();
} else if (connection === 'open') {
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ sukses terhubung ke nomer bot`));
}
});
RexDev.ev.on('creds.update', saveCreds);
RexDev.ev.on('messages.upsert', async (chatUpdate) => {
try {
let cup = chatUpdate.messages?.[0];
if (!proto?.WebMessageInfo || !cup?.message || !cup.key) return;
cup.message = (Object.keys(cup.message)[0] === 'ephemeralMessage')
? cup.message.ephemeralMessage.message
: cup.message;
if (cup.key?.remoteJid === 'status@broadcast') return;
if (cup.key.id.startsWith('BAE5') && cup.key.id.length === 16) return;
if (cup.key.id.startsWith('seannotify')) return;
const m = smsg(RexDev, cup, store);
const { default: handlemsg } = await import('./SeanCase.js');
handlemsg(RexDev, m, chatUpdate, store);
} catch (err) {
console.error(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ error\n`), err);
}
});
} catch (err) {
console.error(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ error\n`), err);
}
}

console.clear
RexStartBot();
console.log(chalkAnimation.rainbow(`
╔═╦═╦╗╔╗
║╬║╦╩╗╔╝
║╗╣╩╦╝╚╗
╚╩╩═╩╝╚╝
╔═╦══╦══╦══╦═╦══╦══╦╗
║║║═╦╣═╦╩║║╣╔╩║║╣╔╗║║
║║║╔╝║╔╝╔║║╣╚╦║║╣╠╣║╚╗
╚═╩╝─╚╝─╚══╩═╩══╩╝╚╩═╝`));

fs.watchFile(__filename, () => {
fs.unwatchFile(__filename);
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ update pada ${__filename}`));
delete require.cache[__filename];
require(__filename);
});