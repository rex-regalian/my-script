import './SeanSettings.js';
import chalk from 'chalk';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import util from 'util';
import { issmsg, GetInfo } from './SeanBase/SeanLibrary/SeanFunction.js';
import axios from 'axios';
import cheerio from 'cheerio';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export default async function (RexDev, m) {
try {
let body = "";
if (m.message) {
body =
m.message.conversation ||
m.message.imageMessage?.caption ||
m.message.videoMessage?.caption ||
m.message.extendedTextMessage?.text ||
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply?.selectedRowId ||
m.message.templateButtonReplyMessage?.selectedId ||
m.text || "";
}

const PrefixInMatch = body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi);
const prefix = PrefixInMatch ? PrefixInMatch[0] : "";
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : "";
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const sender = m.key?.remoteJid || "unknown";
const text = q = args.join(" ");

const floc = {
"key": {
"participant": '6289692052222@s.whatsapp.net',
"remoteJid": "status@broadcast",
"fromMe": false,
"id": "Halo"
},
"message": {
"locationMessage": {
"name": 'Sean Script First Version',
"jpegThumbnail": ''
}
}
}

const reply = (teks) => {
return RexDev.sendMessage(m.chat, {
contextInfo: {
mentionedJid: ['0@s.whatsapp.net'],
documentMessage: {
url: "", 
mimetype: "application/pdf", 
fileLength: "33875000", 
fileName: "Rex Official", 
jpegThumbnail: "https://files.catbox.moe/b5e9j2.jpg"
}
},
text: teks
}, {
quoted: floc
})
}

if (isCmd) {
console.log(chalk.white.bgRed.bold(
`⧼ notif ⧽
⪼ pengirim : ${pushname}
⪼ pesan : ${command}`));
}

switch (command) {

case 'tess':
await RexDev.sendMessage(sender, {
text: `on broo`
});
break

case "cektt":
if (!text) return reply(`Contoh\n${prefix + command} link`)
const videoUrl = text
await GetInfo(videoUrl)
break

default:
}
} catch (err) {
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ error\n]`, err));
}
}

fs.watchFile(__filename, () => {
fs.unwatchFile(__filename);
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ update pada ${__filename}`));
delete require.cache[__filename];
require(__filename);
});
