import * as baileys from "@whiskeysockets/baileys";
import chalk from 'chalk';
import fs from 'fs';
import axios from 'axios';
import cheerio from 'cheerio';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const { proto, getContentType, areJidsSameUser, generateWAMessage } = baileys;
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export function issmsg(RexDev, m, store) {
if (!m) return m;
let M = proto?.WebMessageInfo;
if (!M) {
console.error(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ proto.WebMessageInfo tidak tersedia`);
return m;
}
if (m.key) {
m.id = m.key.id;
m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16;
m.chat = m.key.remoteJid;
m.fromMe = m.key.fromMe;
m.isGroup = m.chat.endsWith('@g.us');
m.sender = RexDev.decodeJid(m.fromMe ? RexDev.user.id : m.participant || m.key.participant || m.chat || '');
if (m.isGroup) m.participant = RexDev.decodeJid(m.key.participant) || '';
}
if (m.message) {
m.mtype = getContentType(m.message);
m.msg = (m.mtype === 'viewOnceMessage') ? 
m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : 
m.message[m.mtype];
m.body = m.message.conversation || m.msg.caption || m.msg.text || 
(m.mtype === 'listResponseMessage' && m.msg.singleSelectReply.selectedRowId) || 
(m.mtype === 'buttonsResponseMessage' && m.msg.selectedButtonId) || 
(m.mtype === 'viewOnceMessage' && m.msg.caption) || m.text;
let quoted = m.quoted = m.msg.contextInfo?.quotedMessage || null;
m.mentionedJid = m.msg.contextInfo?.mentionedJid || [];
if (m.quoted) {
let type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
if (type === 'productMessage') {
type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
}
if (typeof m.quoted === 'string') m.quoted = { text: m.quoted };
m.quoted.mtype = type;
m.quoted.id = m.msg.contextInfo?.stanzaId;
m.quoted.chat = m.msg.contextInfo?.remoteJid || m.chat;
m.quoted.isBaileys = m.quoted.id?.startsWith('BAE5') && m.quoted.id.length === 16;
m.quoted.sender = RexDev.decodeJid(m.msg.contextInfo?.participant);
m.quoted.fromMe = m.quoted.sender === RexDev.decodeJid(RexDev.user.id);
m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || 
m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || '';
m.quoted.mentionedJid = m.msg.contextInfo?.mentionedJid || [];
m.getQuotedObj = async () => {
if (!m.quoted.id) return false;
let q = await store.loadMessage(m.chat, m.quoted.id, RexDev);
return smsg(RexDev, q, store);
};
let vM = m.quoted.fakeObj = M.fromObject({
key: {
remoteJid: m.quoted.chat,
fromMe: m.quoted.fromMe,
id: m.quoted.id
},
message: quoted,
...(m.isGroup ? { participant: m.quoted.sender } : {})
});
m.quoted.delete = () => RexDev.sendMessage(m.quoted.chat, { delete: vM.key });
m.quoted.copyNForward = (jid, forceForward = false, options = {}) => RexDev.copyNForward(jid, vM, forceForward, options);
m.quoted.download = () => RexDev.downloadMediaMessage(m.quoted);
}
}
if (m.msg?.url) m.download = () => RexDev.downloadMediaMessage(m.msg);
m.text = m.body || m.msg.text || m.msg.caption || m.message.conversation || 
m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || '';
m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? 
RexDev.sendMedia(chatId, text, 'file', '', m, { ...options }) : 
RexDev.sendText(chatId, text, m, { ...options });
m.copy = () => smsg(RexDev, M.fromObject(M.toObject(m)));
m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => RexDev.copyNForward(jid, m, forceForward, options);
RexDev.appendTextMessage = async (text, chatUpdate) => {
let messages = await generateWAMessage(m.chat, { text, mentions: m.mentionedJid }, {
userJid: RexDev.user.id,
quoted: m.quoted?.fakeObj
});
messages.key.fromMe = areJidsSameUser(m.sender, RexDev.user.id);
messages.key.id = m.key.id;
messages.pushName = m.pushName;
if (m.isGroup) messages.participant = m.sender;
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
};
RexDev.ev.emit('messages.upsert', msg);
};
return m;
}

export function GetInfo(videoUrl) {
try {
const res = await axios.get(videoUrl, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
'Accept-Language': 'en-US,en;q=0.9',
}
});
const $ = cheerio.load(res.data);
const nextDataScript = $('#__NEXT_DATA__').html();
if (!nextDataScript) return reply("Gagal mengambil data video.");
const jsonData = JSON.parse(nextDataScript);
const itemStruct = jsonData.props?.pageProps?.itemInfo?.itemStruct;
if (!itemStruct) return reply("Video tidak ditemukan atau tidak bisa diakses.");
const { id: videoId, author, stats } = itemStruct;
reply(
`Username  : ${author.uniqueId}
Video ID  : ${videoId}
Views     : ${stats.playCount}
Likes     : ${stats.diggCount}
Comments  : ${stats.commentCount}
Shares    : ${stats.shareCount}`
);
} catch (err) {
reply("Terjadi kesalahan: " + (err.response?.statusText || err.message));
}
}

fs.watchFile(__filename, () => {
fs.unwatchFile(__filename);
console.log(chalk.white.bgRed.bold(
`┏╍╍╍╍╍╍╍╍╍━ ≫
┗ ⪼ update pada ${__filename}`));
delete require.cache[__filename];
require(__filename);
});